import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'l10n/app_localizations.dart';
import 'ui/screens/loading_screen.dart';
import 'ui/screens/role_selection_screen.dart';
import 'ui/screens/register_screen.dart';
import 'logic/cubit/volunteers_cubit.dart';
import 'data/repositories/volunteers_repository.dart';
import 'logic/cubit/volunteer_registration_cubit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/services/database_helper.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized(); // REQUIRED
  await DatabaseHelper.instance.database;

  // Create the repository instance
  final volunteersRepository = VolunteersRepository();

  // Load saved volunteer ID (auto-login)
  final prefs = await SharedPreferences.getInstance();
  final savedVolunteerId = prefs.getString('currentVolunteerId');

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (_) => VolunteersCubit(
            volunteersRepository: volunteersRepository,
          ),
        ),
        BlocProvider(
          create: (_) => VolunteerRegistrationCubit(
            volunteersRepository: volunteersRepository,
          ),
        ),
      ],
      child: EmergencyApp(
        savedVolunteerId: savedVolunteerId,
      ),
    ),
  );
}

class EmergencyApp extends StatefulWidget {
  final String? savedVolunteerId;

  const EmergencyApp({super.key, this.savedVolunteerId});

  static _EmergencyAppState? of(BuildContext context) {
    return context.findAncestorStateOfType<_EmergencyAppState>();
  }

  @override
  State<EmergencyApp> createState() => _EmergencyAppState();
}

class _EmergencyAppState extends State<EmergencyApp> {
  Locale _locale = const Locale('ar');

  Locale get locale => _locale;

  void setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emergency App',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF4A8BB3),
        useMaterial3: true,
      ),
      locale: _locale,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: AppLocalizations.supportedLocales,
      debugShowCheckedModeBanner: false,
      initialRoute: '/loading',
      routes: {
        '/loading': (context) => LoadingScreen(
              savedVolunteerId: widget.savedVolunteerId,
            ),
        '/roleSelection': (context) => const RoleSelectionScreen(),
        '/register': (context) => const RegisterScreen(),
      },
    );
  }

}

