import 'package:flutter/material.dart';
import 'list_volunteer.dart';
import 'prevention_method_screen.dart';
import 'safety_instruction_screen.dart';
import '../widgets/custom_bottom_navbar.dart';
import '../widgets/explore_card.dart';
import '../widgets/page_header.dart'; // <-- import your header
import 'package:url_launcher/url_launcher.dart';
import '../../l10n/app_localizations.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const double whiteContainerTop = 300.0;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      
      // Add the PageHeader here
      appBar: PageHeader(
        onBack: () => Navigator.pop(context), // optional custom back action
      ),

      body: Stack(
        children: [
          // HEADER IMAGE
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: whiteContainerTop,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/images/explore back.jpg',
                  fit: BoxFit.cover,
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color.fromARGB(255, 71, 72, 73).withOpacity(0.5),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // TITLE
          Positioned(
            top: MediaQuery.of(context).padding.top + 60,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10.0),
              child: Text(
                AppLocalizations.of(context)!.exploreTitle,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),

          // WHITE BACKGROUND
          Positioned(
            top: 320,
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(color: const Color(0xFFF5F5F5)),
          ),

          // CARDS SECTION
          Positioned(
            top: 230,
            left: 20,
            right: 20,
            bottom: 0,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // Prevention Methods
                  ExploreCard(
                    title: AppLocalizations.of(context)!.preventionMethods,
                    imagePath: 'assets/images/explore.png',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              const PreventionMethodsScreen(),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 20),

                  // Safety Instructions
                  ExploreCard(
                    title: AppLocalizations.of(context)!.safetyInstructions,
                    imagePath: 'assets/images/ambulance.png',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              const SafetyInstructionsScreen(),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 20),

                  // Volunteers List
                  ExploreCard(
                    title: AppLocalizations.of(context)!.volunteerList,
                    imagePath: 'assets/images/mos3if.png',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                               VolunteerListScreen(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),

      // BOTTOM NAV BAR
      bottomNavigationBar: CustomBottomNavBar(
        onEmergencyTap: () async {
          final Uri phoneUri = Uri.parse('tel:14');
          if (await canLaunchUrl(phoneUri)) {
            await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
          } else {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content:
                      Text(AppLocalizations.of(context)!.cannotOpenPhoneApp),
                  backgroundColor: Colors.red,
                ),
              );
            }
          }
        },
      ),
    );
  }
}