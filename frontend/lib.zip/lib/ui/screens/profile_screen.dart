import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import 'edit_profile.dart';
import 'settings.dart';
import 'terms_conditions.dart';
import '../widgets/custom_bottom_navbar.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../data/models/volunteer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_screen.dart';

class ProfilePage extends StatefulWidget {
  final Volunteer volunteer;

  const ProfilePage({Key? key, required this.volunteer}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool isAcceptable = false;
  String volunteerStatus = "Available"; // default status

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  Future<void> _loadStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      volunteerStatus = prefs.getString('volunteerStatus') ?? "Available";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Header
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: const BoxDecoration(
                    color: Color(0xFF4A8BB3),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(50),
                      bottomRight: Radius.circular(50),
                    ),
                  ),
                  child: Column(
                    children: [
                      // Top row: back + settings
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:
                            Directionality.of(context) == TextDirection.rtl
                                ? [
                                    IconButton(
                                      icon: const Icon(Icons.arrow_back,
                                          color: Colors.white),
                                      onPressed: () => Navigator.pop(context),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.settings,
                                          color: Colors.white),
                                      onPressed: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const SettingsPage()),
                                        );
                                      },
                                    ),
                                  ]
                                : [
                                    IconButton(
                                      icon: const Icon(Icons.settings,
                                          color: Colors.white),
                                      onPressed: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const SettingsPage()),
                                        );
                                      },
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.arrow_forward,
                                          color: Colors.white),
                                      onPressed: () => Navigator.pop(context),
                                    ),
                                  ],
                      ),

                      const SizedBox(height: 16),

                      // Avatar
                      Center(
                        child: Stack(
                          children: [
                            Container(
                              width: 120,
                              height: 120,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/avatar.png',
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: Colors.blue[100],
                                      child: const Icon(
                                        Icons.person,
                                        size: 60,
                                        color: Color.fromARGB(255, 14, 44, 77),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              left: 0,
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.edit,
                                  size: 20,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Welcome text
                      Text(
                        AppLocalizations.of(context)!
                            .welcomeMessage(widget.volunteer.name),
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),

                      const SizedBox(height: 24),
                    ],
                  ),
                ),

                // Contact info
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Text(
                    AppLocalizations.of(context)!.contactInfo,
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                ),

                // Settings container
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildMenuItem(
                          icon: Icons.credit_card,
                          title: AppLocalizations.of(context)!.accountSettings,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const ProfileEditPage()),
                            );
                          },
                        ),
                        const Divider(height: 1),
                        _buildMenuItem(
                          icon: Icons.notifications_outlined,
                          title: AppLocalizations.of(context)!.status,
                          subtitle: volunteerStatus,
                          subtitleColor: Colors.blue,
                          onTap: () async {
                            final selected = await showDialog<String>(
                              context: context,
                              builder: (context) {
                                return SimpleDialog(
                                  title: Text(
                                      AppLocalizations.of(context)!.status),
                                  children: [
                                    SimpleDialogOption(
                                      onPressed: () =>
                                          Navigator.pop(context, "Available"),
                                      child: const Text("Available"),
                                    ),
                                    SimpleDialogOption(
                                      onPressed: () => Navigator.pop(
                                          context, "Not Available"),
                                      child: const Text("Not Available"),
                                    ),
                                  ],
                                );
                              },
                            );

                            if (selected != null) {
                              final prefs =
                                  await SharedPreferences.getInstance();
                              await prefs.setString(
                                  'volunteerStatus', selected);
                              setState(() {
                                volunteerStatus = selected;
                              });
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                // Additional options
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildMenuItem(
                          icon: Icons.format_quote,
                          title: AppLocalizations.of(context)!.contactUs,
                          onTap: () {
                            final Uri emailUri = Uri(
                              scheme: 'mailto',
                              path: 'support@yourapp.com',
                              query: 'subject=Support Request',
                            );
                          },
                        ),
                        const Divider(height: 1),
                        _buildMenuItem(
                          icon: Icons.lock_outline,
                          title: AppLocalizations.of(context)!.privacyPolicy,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const PrivacyPolicyPage()),
                            );
                          },
                        ),
                        const Divider(height: 1),
                        _buildMenuItem(
                          icon: Icons.logout,
                          title: AppLocalizations.of(context)!.logout,
                          onTap: () {
                            _showLogoutDialog(context);
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 30),

                if (!isAcceptable)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32.0),
                    child: Text(
                      AppLocalizations.of(context)!.verificationMessage,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.red[400],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(
          onEmergencyTap: () async {
            final Uri phoneUri = Uri.parse('tel:14');
            if (await canLaunchUrl(phoneUri)) {
              await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
            } else {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content:
                        Text(AppLocalizations.of(context)!.cannotOpenPhoneApp),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            }
          },
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    String? subtitle,
    Color? subtitleColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
        child: Row(
          children: [
            Icon(icon, size: 28, color: Colors.black87),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87)),
                  if (subtitle != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(subtitle,
                          style: TextStyle(
                              fontSize: 14,
                              color: subtitleColor ?? Colors.grey[600])),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text(AppLocalizations.of(context)!.logout),
            content: Text(AppLocalizations.of(context)!.logoutConfirmMessage),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(AppLocalizations.of(context)!.cancel),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.remove('currentVolunteerId');
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false,
                  );
                },
                child: Text(AppLocalizations.of(context)!.logout,
                    style: const TextStyle(color: Colors.red)),
              ),
            ],
          ),
        );
      },
    );
  }
}
