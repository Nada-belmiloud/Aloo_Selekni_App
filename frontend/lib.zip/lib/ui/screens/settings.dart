import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import 'language_page.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/custom_bottom_navbar.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({Key? key}) : super(key: key);

  final List<Map<String, dynamic>> options = const [
    {'key': 'changeLanguage', 'icon': Icons.language},
    {'key': 'followUs', 'icon': Icons.people},
    {'key': 'faq', 'icon': Icons.help_outline},
    {'key': 'contactUs', 'icon': Icons.contact_mail},
    {'key': 'rateApp', 'icon': Icons.star_rate},
  ];

  String getLocalizedString(BuildContext context, String key) {
    final loc = AppLocalizations.of(context)!;
    switch (key) {
      case 'changeLanguage':
        return loc.changeLanguage;
      case 'followUs':
        return loc.followUs;
      case 'faq':
        return loc.faq;
      case 'contactUs':
        return loc.contactUs;
      case 'rateApp':
        return loc.rateApp;
      default:
        return key;
    }
  }

  void handleOptionTap(BuildContext context, String key) async {
  switch (key) {
    case 'changeLanguage':
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LanguagePage()),
      );
      break;
    case 'faq':
      final Uri faqUri = Uri.parse('https://www.yourwebsite.com/faq');
      if (await canLaunchUrl(faqUri)) {
        await launchUrl(faqUri, mode: LaunchMode.externalApplication);
      }
      break;
    case 'contactUs':
      final Uri emailUri = Uri(
        scheme: 'mailto',
        path: 'support@yourapp.com',
        query: 'subject=Support Request',
      );
      if (await canLaunchUrl(emailUri)) {
        await launchUrl(emailUri, mode: LaunchMode.externalApplication);
      }
      break;
    case 'rateApp':
      final Uri storeUri = Uri.parse(
          'https://play.google.com/store/apps/details?id=com.yourapp');
      if (await canLaunchUrl(storeUri)) {
        await launchUrl(storeUri, mode: LaunchMode.externalApplication);
      }
      break;
    default:
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.cannotOpenPhoneApp)),
      );
  }
}


  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: Directionality.of(context),
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.of(context)!.settingsTitle),
          centerTitle: true,
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: Colors.black),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Expanded(
                child: ListView.separated(
                  itemCount: options.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final option = options[index];
                    return GestureDetector(
                      onTap: () => handleOptionTap(context, option['key']),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 18),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 8,
                                offset: const Offset(0, 3)),
                          ],
                        ),
                        child: Row(
                          children: [
                            Icon(option['icon'], color: const Color(0xFF5B9FCA)),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Text(
                                getLocalizedString(context, option['key']),
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w500),
                              ),
                            ),
                            const Icon(Icons.arrow_forward_ios, size: 16),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(
          onEmergencyTap: () async {
            final Uri phoneUri = Uri.parse('tel:14');
            if (await canLaunchUrl(phoneUri)) {
              await launchUrl(phoneUri,
                  mode: LaunchMode.externalApplication);
            } else {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                        AppLocalizations.of(context)!.cannotOpenPhoneApp),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            }
          },
        ),
      ),
    );
  }
}
