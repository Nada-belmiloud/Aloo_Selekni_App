import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import '../../data/repositories/volunteers_repository.dart';
import 'emergency_button_screen.dart';
import 'profile_screen.dart';
import 'role_selection_screen.dart';

class LoadingScreen extends StatefulWidget {
  final String? savedVolunteerId;

  const LoadingScreen({Key? key, this.savedVolunteerId}) : super(key: key);

  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  @override
  @override
void initState() {
  super.initState();

  Future.delayed(const Duration(seconds: 2), () {
    if (!mounted) return;

    if (widget.savedVolunteerId != null) {
      // User is already logged in → go to EmergencyButtonScreen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const EmergencyButtonScreen(),
        ),
      );
    } else {
      // No saved user → go to role selection
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const EmergencyButtonScreen(),
        ),
      );
    }
  });
}

  Future<void> _navigate() async {
    await Future.delayed(const Duration(seconds: 3));

    if (!mounted) return;

    // If user was already logged in previously
    if (widget.savedVolunteerId != null) {
      final repo = VolunteersRepository();
      final volunteer =
          await repo.getVolunteerById(widget.savedVolunteerId!);

      if (volunteer != null && mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ProfilePage(volunteer: volunteer),
          ),
        );
        return;
      }
    }

    // If no saved login → go to the Emergency Button screen
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const EmergencyButtonScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF4A8BB3),
              Color(0xFF4A8BB3),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 2),
                Image.asset(
                  'assets/ambulance.png',
                  width: 300,
                  height: 200,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      width: 300,
                      height: 200,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.local_hospital,
                        size: 100,
                        color: Colors.white,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 60),
                Text(
                  AppLocalizations.of(context)!.loadingTitle,
                  style: const TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  AppLocalizations.of(context)!.loadingSubtitle,
                  style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                ),
                const Spacer(flex: 2),
                const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
