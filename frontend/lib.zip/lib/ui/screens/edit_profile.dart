import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/custom_bottom_navbar.dart';
import '../../l10n/app_localizations.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profile Edit',
      debugShowCheckedModeBanner: false,
      // Localization setup
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      supportedLocales: AppLocalizations.supportedLocales,
      // do not force a locale here — let the system or your app choose
      theme: ThemeData(
        primarySwatch: Colors.red,
        fontFamily: 'Cairo',
      ),
      home: const ProfileEditPage(),
    );
  }
}

class ProfileEditPage extends StatefulWidget {
  const ProfileEditPage({Key? key}) : super(key: key);

  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController =
  TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  // store selected as codes (stable ids)
  String? _selectedWilayaCode;
  String? _selectedGenderCode;

  // list of wilaya codes (58)
  final List<String> _wilayaCodes = [
    'adrar','chlef','laghouat','oum_el_bouaghi','batna','bejaia','biskra','béchar',
    'blida','bouira','tamanrasset','tbessa','tlemcen','tilioust','tizi_ouzou','algiers',
    'djelfa','jijel','setif','saida','skikda','sidi_bel_abbes','annaba','guelma',
    'constantine','médéa','mostaganem','mila','msila','maskara','ouargla','oran',
    'el_bayadh','illizi','borg_bouarreridj','boumerdes','el_tarf','tindouf','tissemsilt',
    'el_oued','khenchela','soukh_ahras','tipaza','mila2','ain_defla','naama','ain_temouchent',
    'ghardaia','relizane','timimoun','bordj_baji_mokhtar','ouled_jellal','bni_abbes','ain_saleh',
    'ain_guezzam','touggourt','djanet','el_meghier','el_meniaa'
  ];

  // genders as codes
  final List<String> _genderCodes = ['male', 'female'];

  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      final t = AppLocalizations.of(context)!;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            t.updatedSuccessfully,
            textAlign: TextAlign.right,
          ),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  // helper: map wilaya code -> localized label using AppLocalizations
  Map<String, String> _wilayaLabels(AppLocalizations t) => {
        'adrar': t.wilaya_adrar,
        'chlef': t.wilaya_chlef,
        'laghouat': t.wilaya_laghouat,
        'oum_el_bouaghi': t.wilaya_oum_el_bouaghi,
        'batna': t.wilaya_batna,
        'bejaia': t.wilaya_bejaia,
        'biskra': t.wilaya_biskra,
        'béchar': t.wilaya_bechar,
        'blida': t.wilaya_blida,
        'bouira': t.wilaya_bouira,
        'tamanrasset': t.wilaya_tamanrasset,
        'tbessa': t.wilaya_tbessa,
        'tlemcen': t.wilaya_tlemcen,
        'tilioust': t.wilaya_tiaret,
        'tizi_ouzou': t.wilaya_tizi_ouzou,
        'algiers': t.wilaya_algiers,
        'djelfa': t.wilaya_djelfa,
        'jijel': t.wilaya_jijel,
        'setif': t.wilaya_setif,
        'saida': t.wilaya_saida,
        'skikda': t.wilaya_skikda,
        'sidi_bel_abbes': t.wilaya_sidi_bel_abbes,
        'annaba': t.wilaya_annaba,
        'guelma': t.wilaya_guelma,
        'constantine': t.wilaya_constantine,
        'médéa': t.wilaya_medea,
        'mostaganem': t.wilaya_mostaganem,
        'mila': t.wilaya_mila,
        'msila': t.wilaya_msila,
        'maskara': t.wilaya_mascara,
        'ouargla': t.wilaya_ouargla,
        'oran': t.wilaya_oran,
        'el_bayadh': t.wilaya_el_bayadh,
        'illizi': t.wilaya_illizi,
        'borg_bouarreridj': t.wilaya_bordj_bou_arreridj,
        'boumerdes': t.wilaya_boumerdes,
        'el_tarf': t.wilaya_el_tarf,
        'tindouf': t.wilaya_tindouf,
        'tissemsilt': t.wilaya_tissemsilt,
        'el_oued': t.wilaya_el_oued,
        'khenchela': t.wilaya_khenchela,
        'soukh_ahras': t.wilaya_souk_ahras,
        'tipaza': t.wilaya_tipaza,
        'mila2': t.wilaya_mila2,
        'ain_defla': t.wilaya_ain_defla,
        'naama': t.wilaya_naama,
        'ain_temouchent': t.wilaya_ain_temouchent,
        'ghardaia': t.wilaya_ghardaia,
        'relizane': t.wilaya_relizane,
        'timimoun': t.wilaya_timimoun,
        'bordj_baji_mokhtar': t.wilaya_bordj_baji_mokhtar,
        'ouled_jellal': t.wilaya_ouled_jellal,
        'bni_abbes': t.wilaya_beni_abbes,
        'ain_saleh': t.wilaya_ain_saleh,
        'ain_guezzam': t.wilaya_ain_guezzam,
        'touggourt': t.wilaya_touggourt,
        'djanet': t.wilaya_djanet,
        'el_meghier': t.wilaya_el_meghier,
        'el_meniaa': t.wilaya_el_meniaa,
      };

  Map<String, String> _genderLabels(AppLocalizations t) => {
        'male': t.gender_male,
        'female': t.gender_female,
      };

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final wilayaLabels = _wilayaLabels(t);
    final genderLabels = _genderLabels(t);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
            icon: const Icon(Icons.settings, color: Colors.black),
            onPressed: () {},
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.arrow_forward, color: Colors.black),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  Text(
                    t.editInfo,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Full Name
                  _buildTextField(
                    controller: _nameController,
                    hintText: t.fullName,
                    keyboardType: TextInputType.name,
                  ),
                  const SizedBox(height: 16),

                  // Email
                  _buildTextField(
                    controller: _emailController,
                    hintText: t.email,
                    keyboardType: TextInputType.emailAddress,
                  ),
                  const SizedBox(height: 16),

                  // Phone with Flag
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey[300]!),
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: _buildAlgeriaFlag(),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _phoneController,
                            textAlign: TextAlign.right,
                            keyboardType: TextInputType.phone,
                            decoration: InputDecoration(
                              hintText: t.phone,
                              border: InputBorder.none,
                              contentPadding:
                                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Wilaya and Gender
                  Row(
                    children: [
                      Expanded(
                        child: _buildDropdown(
                          value: _selectedWilayaCode,
                          hint: t.wilaya,
                          itemsCodes: _wilayaCodes,
                          itemLabel: (code) => wilayaLabels[code] ?? code,
                          onChanged: (value) {
                            setState(() {
                              _selectedWilayaCode = value;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildDropdown(
                          value: _selectedGenderCode,
                          hint: t.gender,
                          itemsCodes: _genderCodes,
                          itemLabel: (code) => genderLabels[code] ?? code,
                          onChanged: (value) {
                            setState(() {
                              _selectedGenderCode = value;
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Address
                  _buildTextField(
                    controller: _addressController,
                    hintText: t.address,
                    keyboardType: TextInputType.streetAddress,
                  ),
                  const SizedBox(height: 32),

                  // Submit Button
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _handleSubmit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[500],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        t.update,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(
          onEmergencyTap: () async {
            final Uri phoneUri = Uri.parse('tel:14');
            if (await canLaunchUrl(phoneUri)) {
              await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
            } else {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(t.cannotOpenPhoneApp), backgroundColor: Colors.red),
                );
              }
            }
          },
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextInputType? keyboardType,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: TextField(
        controller: controller,
        textAlign: TextAlign.right,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hintText,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String hint,
    required List<String> itemsCodes,
    required String Function(String code) itemLabel,
    required Function(String?) onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Text(hint, textAlign: TextAlign.right),
          isExpanded: true,
          icon: const Icon(Icons.arrow_drop_down),
          items: itemsCodes.map((String code) {
            return DropdownMenuItem<String>(
              value: code,
              alignment: AlignmentDirectional.centerEnd,
              child: Text(itemLabel(code), textAlign: TextAlign.right),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  // simple algeria flag widget
  Widget _buildAlgeriaFlag() {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: ClipOval(
        child: Row(
          children: [
            Expanded(child: Container(color: Colors.green[700])),
            Expanded(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(color: Colors.white),
                  Icon(Icons.star, color: Colors.red[700], size: 20),
                ],
              ),
            ),
            Expanded(child: Container(color: Colors.red[700])),
          ],
        ),
      ),
    );
  }
}