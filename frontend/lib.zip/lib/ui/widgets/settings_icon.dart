import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import '../screens/settings.dart'; 

class SettingsIcon extends StatelessWidget {
  const SettingsIcon({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool isRtl = Directionality.of(context) == TextDirection.rtl;

    return IconButton(
      icon: const Icon(Icons.settings, size: 28, color: Colors.black),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const SettingsPage()),
        );
      },
      alignment: isRtl ? Alignment.centerLeft : Alignment.centerRight,
      tooltip: AppLocalizations.of(context)!.settingsTooltip,
    );
  }
}
